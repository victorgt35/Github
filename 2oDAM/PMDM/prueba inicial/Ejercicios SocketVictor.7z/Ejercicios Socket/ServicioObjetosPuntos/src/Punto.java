public class Punto {
    public static int x = 0;
    public static int y = 0;

    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }

}
